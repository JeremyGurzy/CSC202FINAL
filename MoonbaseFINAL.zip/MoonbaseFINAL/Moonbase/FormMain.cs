﻿/*
 Jeremy Gurzynski
 CSC202
 jgurzynski85952@uat.edu
 MoonBase Alpha Final Project
 */

//These lines are used for various functionalities of C#
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
//This allows sounds and videos to play in the GUI
using System.Media;
//Name of our file
namespace Moonbase
{
    //Declares our Moonbase that inherits from form
    public partial class Moonbase : Form
    {
        //random number generator for the moonquake event
        private Random random = new Random(); 
        //private int created for tracking locations, kept this so I did not have to edit previous one any further
        private int currentLoc;
        //string for the log message created as a global variable
        string messageFile = "logMessage.txt";
        //variable created for our sounds
        private SoundPlayer soundPlayer;

        //Global variables for the whole form, each have 11. However not all are used, had to update each number 
        //equally to avoid all errors I was receiving when running the program
        public string[] RN = new string[11];
        public string[] Desc = new string[11];
        public string[] BI = new string[11];


        //created a class called area for room names, descriptions and background images
        class area 
        {
            //These lines are changed the public strings to private
            private string[] roomNames = new string[11];
            private string[] roomDesc = new string[11];
            private string[] backgroundImage = new string[11];

            //constructor for our arrays
            public area(string[] RN, string[] Desc, string[] BI)
            {
                //for loop 
                //i< is how many times you want something to be done, it will be less than 5. i++ goes up by one
                for (int i = 0; i<roomNames.Length; i++) 
                {
                    //these copy the arrays, EXPLAINED: roomname "0" will be the same as RN "0"
                    roomNames[i] = RN[i];
                    roomDesc[i] = Desc[i];
                    backgroundImage[i] = BI[i];
 
                }
            }
            //string function will get the room name and then set it
            public string getRoom(int i)
            {
                //function will return the room name and the integer assigned from the array
                return roomNames[i];
            }
            //string function will get the description and then set it
            public string getDesc(int i) 
            {
                //function will return the room description and the integer assigned from the array
                return roomDesc[i];
            }
            //string function for the background image and then set it
            public string getBackImage(int i)
            {
                //function will return the background image and the integer assigned from the array
                return backgroundImage[i]; 
            }
        }

        //Constructor for our form
        public Moonbase()
        {
            //Initializes control objects, properties, and adds to proper control collections.
            InitializeComponent();
            //Call the exterior function to welcome user and ask question
            mainMenu();


            //These lines are the room names for each area
            RN[0] = "Central Control Room";
            RN[1] = "Operations Room";
            RN[2] = "Security Room";
            RN[3] = "Communications Room";
            RN[4] = "Engineering Room";
            RN[5] = "Berthing";
            RN[6] = "Medical Bay";
            RN[7] = "Corridor to Berthing";
            RN[8] = "Corridor to Medical Bay";



            //Description for Central Control Room
            Desc[0] = "A vast and open circular room that is the center of the Cosmos Command. The Central Control Room is the brains of the base and connects with four work stations: operations, engineering, security, and communcations station. \r\n\r\nThe Central Control Room breaks off into several corridors that connect around the base creating easier access to all compartments in the event of an emergency.";
            //Description for Operations
            Desc[1] = " Oversees and coordinates all mission activities and operational directives. Here is where mission plans are coordinated, schedules are managed, and vital decisions are made. It houses advanced monitoring screens displaying real-time data from various base systems, ensuring everything from life support to scientific experiments runs smoothly.";
            //DESCRIPTION FOR SECURITY
            Desc[2] = "Conducts and oversees all security of the command. Security Personnel monitor all interior and exterior cameras ensuring the safety of all personnel within the command. This room is equipped with state-of-the-art surveillance systems, security gear, security weaponry, and more.\r\n";
            //Description for Communications
            Desc[3] = "Manages all external communications between Earth and the Moon, as well as internal communications within the base. The Communications Room is equipped with advanced communication systems, ensuring that messages, video calls, and critical data flow smoothly from here to Earth.";
            //Description for Engineering
            Desc[4] = "Monitors all technical systems and base infrastructure. Engineers and technicians maintain and improve the base's infrastructure and technology. Here you will find various equipment such as advanced tools, 3D printers for rapid prototyping, and diagnostic stations to ensure every component of the base operates at peak performance.";
            //Description for Berthing
            Desc[5] = "A resting and sleeping area for personnel. Berthing includes individual sleeping pods and personal storage.";
            //Description for Medical Bay
            Desc[6] = "The Medical Bay is designed to handle a wide range of medical emergencies and routine health care needs for the station's crew. It is equipped with advanced medical technology to ensure the well-being of astronauts in the unique and challenging environment of space.";
            //Corridor to the berthing description
            Desc[7] = "Corridor leading to the Berthing Area is designed to facilitate easy and safe access for crew members and visitors as they prepare for rest and relaxation. This well-maintained route ensures a smooth transition from the central control station to the personal and communal living spaces where crew members sleep and unwind.";
            //Corridor to medical bay description
            Desc[8] = "Corridor leading to the Medical Bay is a crucial transit route designed to ensure quick and safe access to medical facilities in emergency situations. It is engineered to facilitate both routine and urgent medical care, providing a clear, secure, and well-marked path to the station’s healthcare hub.";
            
           


            //These lines are all set with the path for each background image
            BI[0] = "ControlRoom.jpg";
            BI[1] = "opsroom.jpg";
            BI[2] = "secroom.jpg";
            BI[3] = "comroom.jpg";
            BI[4] = "engRoom.jpg";
            BI[5] = "room.jpg";
            BI[6] = "medicalBay.jpg";
            BI[7] = "compscreen.jpg";
            BI[8] = "corridor1.jpg";
            BI[9] = "corridor2.jpg";
            BI[10] = "Chilling.jpg";

        }
        
        //Log File Function with the location string variable
        private void logLocation(string location) 
        {
            //This is for collecting the current date and time with the location
            string logMessage = $"{DateTime.Now}: Moved to {location}";
            //This is where the information will be logged
            string logFile = "locationLog.txt";
            //Try for exception handling if the file can or cannot be appended
            try
            {
                //StreamWriter is used for writing to the log files
                using (StreamWriter lw = File.AppendText(logFile))
                {
                    //Function for writing the lines
                    lw.WriteLine(logMessage);
                }
            }
            //Catch made to display error message in the event the location cannot be logged
            catch (IOException ex)
            {
                //Message will display if there as an error logging the location
                MessageBox.Show("Error logging location " + ex.Message);
            
            }
        }
        //Function for writing to a text file FOR SECURITY only
        private void logMessage(string message)
        {
            //string variable for what will be written to the file
            string logMessage = $"{DateTime.Now}: {message}";
         
            //try for exception handling if file can or cannot be written to
            try 
            {
                //stream writer function for writing to the log file
                using (StreamWriter mw = new StreamWriter(messageFile))
                {
                    //Function for writing the lines
                    mw.WriteLine(logMessage);
                } 
            }
            //catch for exception handling (IOException is input output)
            catch (IOException)
            {
                //message will display if there is an error writing to the file
                MessageBox.Show("Error writing message to the log. Try Again.");
            }

        }
        //Function for reading a file
        private void readMessage() 
        {
            //try for exception handling if file can or cannot be read
            try
            {
                //string created to assign the read function
                string lastMessage;
                //stream reader function will fetch the file and read it
                using (StreamReader readLog = new StreamReader(messageFile))
                {
                    //variable for reading the log file
                    lastMessage = readLog.ReadToEnd();
                    //message will display with recent line from the file
                    MessageBox.Show(lastMessage);
                }

            }
            //catch for exception handling
            catch (IOException)
            {
                //message will display when file is unreadable
                MessageBox.Show("Unable to read selected file");
            }
        }
        //Moonquake function created only for central control, async is for the await function
        private async void moonQuakeSimulation()
        {
            //While loop for the moonquake event
            while (true)
            {
                //sets all buttons to disable
                allButtons(false);
                //displays when moonquake occurs
                MessageBox.Show("Emergency Lockdown! A Moonquake is occuring!!");
                //logs when moonquake is in effect
                logLocation("Moonquake in effect");
                //time delay of 3 seconds
                await Task.Delay(3000);
                //displays message when moonquake has passed
                MessageBox.Show("Moonquake has passed, lockdown is over.");
                //logs the moonquake when it happens
                logLocation("Moonquake passed");
                //function sets all buttons back to enable
                allButtons(true);
                //This will break the loop once event is over
                break;

            }
        }
        //function made to disable all buttons during a moon quake, this function has a bool variable for disabling and enabling the buttons within
        private void allButtons(bool enabled)
        {
            //Each of these lines has the buttons enabled until the bool is set to false when the function is called
            BTNeng.Enabled = enabled;
            BTNcoms.Enabled = enabled;
            BTNops.Enabled = enabled;
            BTNsec.Enabled = enabled;
            BTNhallway1.Enabled = enabled;
            BTNhallway2.Enabled = enabled;
            BTNback2.Enabled = enabled;

        }
        //bool function for the moonquake event
        private bool randomChanceMoonQuake()
        {
            //int possibility of a moonquake occurring, this is a 50% chance
            int possibleQuake = 50;
            //generates a number between 0 and 99
            int chance = random.Next(100); 
            //Function will return if chance is less than possibleQuake causing the event, if not less than then nothing will happen 
            return chance < possibleQuake;
        }


        //Function for each area
        //function for central control room, 0
        //async allows me to utilize the await function
        private void centralControlRoom() 
        {
            //Call the class and call it Cosmos with arrays sent into it
            area Cosmos = new area(RN, Desc, BI);
            //These two lines will call the functions with the assigned array data to change the room name and description in our groupboxes
            string room = Cosmos.getRoom(0);
            string desc = Cosmos.getDesc(0);

            //Message box will display with the location with assigned number in array function, $ symbol for calling the string
            MessageBox.Show($"Going to: {Cosmos.getRoom(0)}");


            //Call the location with the assigned number from our array
            currentLoc = 0;

            //if created to show and hide necessary data
            if (currentLoc == 0)
            {
                //set the groupboxes to show because they are hidden on the main screen
                GBpernav.Show();
                GBcenconroom.Show();
                BTNback2.Show();
                //button set to hide
                BTNcomputer.Hide();
                ///These lines are disabling and enabling certain buttons
                BTNcencon.Enabled = false;
                BTNeng.Enabled = true;
                BTNcoms.Enabled = true;
                BTNops.Enabled = true;
                BTNsec.Enabled = true;
                BTNhallway1.Enabled = true;
                BTNhallway2.Enabled = true;
                BTNmedbay.Enabled = false;
                BTNberthing.Enabled = false;
                

                //sets the location of a group box
                GBcenconroom.Location = new Point(42, 23);
                //sets the location of a group box
                GBpernav.Location = new Point(850, 25);
                //next two lines set the text box information to the array assigned
                textBox1.Text = room;
                textBox2.Text = desc;
                //sets the background image according to the array assigned
                BackgroundImage = Image.FromFile(Cosmos.getBackImage(0));


            }

            //if created with the random chance function to simulate the moon quake at random times only in the central control
            if (randomChanceMoonQuake())
            {
                //call the moonquake function
                moonQuakeSimulation();
            }

            //Call log location function with the name of the room for logging
            logLocation("Central Control Room");


        }
        //Function for Operations, 1
        private void operationsRoom() 
        {
            //Call the class and call it Cosmos with arrays sent into it
            area Cosmos = new area(RN, Desc, BI);
            //These two lines will call the functions with the assigned array data to change the room name and description in our groupboxes
            string room = Cosmos.getRoom(1);
            string desc = Cosmos.getDesc(1);

            //Message box will display location name and short description from the array data
            MessageBox.Show($"Going to: {Cosmos.getRoom(1)}");

            //sets the current location
            currentLoc = 1;

        
            //if created to show and hide necessary data
            if (currentLoc == 1)
            {
                //These lines are disabling and enabling certain buttons
                BTNcencon.Enabled = true;
                BTNeng.Enabled = false;
                BTNcoms.Enabled = false;
                BTNops.Enabled = false;
                BTNsec.Enabled = false;
                BTNmedbay.Enabled = false;
                BTNberthing.Enabled = false;
                BTNhallway1.Enabled = false;
                BTNhallway2.Enabled = false;
                //sets the location of a group box
                GBcenconroom.Location = new Point(42, 23);
                //sets the location of a group box
                GBpernav.Location = new Point(850, 25);
                //next two lines set the text box information to the array assigned
                textBox1.Text = room;
                textBox2.Text = desc;
                //sets the background image according to the array assigned
                BackgroundImage = Image.FromFile(Cosmos.getBackImage(1));

            }
            //Call log location function with the name of the room for logging
            logLocation("Operations Room");
        }
        //Function for Security, 2
        private void securityRoom() 
        {
            //Call the class and call it Cosmos with arrays sent into it
            area Cosmos = new area(RN, Desc, BI);
            //These two lines will call the functions with the assigned array data to change the room name and description in our groupboxes
            string room = Cosmos.getRoom(2);
            string desc = Cosmos.getDesc(2);
            

            //Message box will display location name and short description from the array data
            MessageBox.Show($"Going to: {Cosmos.getRoom(2)}");
            //sets the current location
            currentLoc = 2;

            //if created to show and hide necessary data
            if (currentLoc == 2)
            {
                //These lines are disabling and enabling certain buttons
                BTNcencon.Enabled = true;
                BTNeng.Enabled = false;
                BTNcoms.Enabled = false;
                BTNops.Enabled = false;
                BTNsec.Enabled = false;
                BTNmedbay.Enabled = false;
                BTNberthing.Enabled = false;
                BTNhallway1.Enabled = false;
                BTNhallway2.Enabled = false;
                //These lines show and hide necessary elements, added because they dissapear upon hitting the back button
                BTNcomputer.Show();
                GBcompscreen.Hide();
                GBcenconroom.Show();
                GBpernav.Show();
                BTNback2.Show();
                //sets the location of a group box
                GBcenconroom.Location = new Point(42, 23);
                //sets the location of a group box
                GBpernav.Location = new Point(850, 25);
                //next two lines set the text box information to the array assigned
                textBox1.Text = room;
                textBox2.Text = desc;
                //sets the background image according to the array assigned
                BackgroundImage = Image.FromFile(Cosmos.getBackImage(2));


            }
            //Call log location function with the name of the room for logging
            logLocation("Security Room");
        }
        //Function for Communications
        private void communicationsRoom()
        {
            //Call the class and call it Cosmos with arrays sent into it
            area Cosmos = new area(RN, Desc, BI);
            //These two lines will call the functions with the assigned array data to change the room name and description in our groupboxes
            string room = Cosmos.getRoom(3);
            string desc = Cosmos.getDesc(3);


            //Message box will display location name and short description from the array data
            MessageBox.Show($"Going to: {Cosmos.getRoom(3)}");
            //Sets the current location
            currentLoc = 3;

            //if created to show and hide necessary data
            if (currentLoc == 3)
            {
                //These lines are disabling and enabling certain buttons
                BTNcencon.Enabled = true;
                BTNeng.Enabled = false;
                BTNcoms.Enabled = false;
                BTNops.Enabled = false;
                BTNsec.Enabled = false;
                BTNmedbay.Enabled = false;
                BTNberthing.Enabled = false;
                BTNhallway1.Enabled = false;
                BTNhallway2.Enabled = false;
                //sets the location of a group box
                GBcenconroom.Location = new Point(42, 23);
                //sets the location of a group box
                GBpernav.Location = new Point(850, 25);
                //next two lines set the text box information to the array assigned
                textBox1.Text = room;
                textBox2.Text = desc;
                //sets the background image according to the array assigned
                BackgroundImage = Image.FromFile(Cosmos.getBackImage(3));
            }
        
            //Call log location function with the name of the room for logging
            logLocation("Communications Room");
        }
        //Function for Engineering
        private void engineeringRoom()
        {
            //Call the class and call it Cosmos with arrays sent into it
            area Cosmos = new area(RN, Desc, BI);
            //These two lines will call the functions with the assigned array data to change the room name and description in our groupboxes
            string room = Cosmos.getRoom(4);
            string desc = Cosmos.getDesc(4);


            //Message box will display location name and short description from the array data
            MessageBox.Show($"Going to: {Cosmos.getRoom(4)}");

            //set the current location for the if statement
            currentLoc = 4;

            //if created to show and hide necessary data
            if (currentLoc == 4)
            {
                //These lines are disabling and enabling certain buttons
                BTNcencon.Enabled = true;
                BTNeng.Enabled = false;
                BTNcoms.Enabled = false;
                BTNops.Enabled = false;
                BTNsec.Enabled = false;
                BTNmedbay.Enabled = false;
                BTNberthing.Enabled = false;
                BTNhallway1.Enabled = false;
                BTNhallway2.Enabled = false;
                //sets the location of a group box
                GBcenconroom.Location = new Point(42, 340);
                //sets the location of a group box
                GBpernav.Location = new Point(850, 25);
                //next two lines set the text box information to the array assigned
                textBox1.Text = room;
                textBox2.Text = desc;
                //sets the background image according to the array assigned
                BackgroundImage = Image.FromFile(Cosmos.getBackImage(4));

            }

            //Call log location function with the name of the room for logging
            logLocation("Engineering Room");
        }
        //Function for berthing
        private void berthing()
        {
            //Call the class and call it Cosmos with arrays sent into it
            area Cosmos = new area(RN, Desc, BI);
            //These two lines will call the functions with the assigned array data to change the room name and description in our groupboxes
            string room = Cosmos.getRoom(5);
            string desc = Cosmos.getDesc(5);


            //Message box will display location name 
            MessageBox.Show($"Going to: {Cosmos.getRoom(5)}");

            //Sets the current location
            currentLoc = 5;

            //if created to show and hide necessary data
            if (currentLoc == 5)
            {
                //These lines are disabling and enabling certain buttons
                BTNcencon.Enabled = false;
                BTNeng.Enabled = false;
                BTNcoms.Enabled = false;
                BTNops.Enabled = false;
                BTNsec.Enabled = false;
                BTNhallway1.Enabled = false;
                BTNmedbay.Enabled = false;
                BTNhallway2.Enabled = true;
                BTNberthing.Enabled = false;
                //sets the location of a group box
                GBcenconroom.Location = new Point(42, 23);
                //sets the location of a group box
                GBpernav.Location = new Point(850, 25);
                //next two lines set the text box information to the array assigned
                textBox1.Text = room;
                textBox2.Text = desc;
                //sets the background image according to the array assigned
                BackgroundImage = Image.FromFile(Cosmos.getBackImage(5));

            }
            //logs the location to the log file
            logLocation("Berthing");

        }
        //function for the medical bay
        private void medicalBay()
        {
            //Call the class and call it Cosmos with arrays sent into it
            area Cosmos = new area(RN, Desc, BI);
            //These two lines will call the functions with the assigned array data to change the room name and description in our groupboxes
            string room = Cosmos.getRoom(6);
            string desc = Cosmos.getDesc(6);


            //Message box will display location name 
            MessageBox.Show($"Going to: {Cosmos.getRoom(6)}");

            //Sets the current location
            currentLoc = 6;

            //if created to show and hide necessary data
            if (currentLoc == 6)
            {
                //These lines are disabling and enabling certain buttons
                BTNcencon.Enabled = false;
                BTNeng.Enabled = false;
                BTNcoms.Enabled = false;
                BTNops.Enabled = false;
                BTNsec.Enabled = false;
                BTNhallway2.Enabled = false;
                BTNhallway1 .Enabled = true;
                BTNberthing.Enabled = false;
                BTNmedbay.Enabled = false;
                //sets the location of a group box
                GBcenconroom.Location = new Point(42, 23);
                //sets the location of a group box
                GBpernav.Location = new Point(850, 25);
                //next two lines set the text box information to the array assigned
                textBox1.Text = room;
                textBox2.Text = desc;
                //sets the background image according to the array assigned
                BackgroundImage = Image.FromFile(Cosmos.getBackImage(6));



            }
            //logs location to log file
            logLocation("Medical Bay");
        }
        //Function for corridor to berthing
        private void corridorToBerthing() 
        {
            //Call the class and call it Cosmos with arrays sent into it
            area Cosmos = new area(RN, Desc, BI);
            //These two lines will call the functions with the assigned array data to change the room name and description in our groupboxes
            string room = Cosmos.getRoom(7);
            string desc = Cosmos.getDesc(7);


            //Message box will display location name 
            MessageBox.Show($"Going through: {Cosmos.getRoom(7)}");

            //Sets the current location
            currentLoc = 7;

            //if created to show and hide necessary data
            if (currentLoc == 7)
            {
                //These lines are disabling and enabling certain buttons
                BTNcencon.Enabled = true;
                BTNeng.Enabled = false;
                BTNcoms.Enabled = false;
                BTNops.Enabled = false;
                BTNsec.Enabled = false;
                BTNhallway2.Enabled = false;
                BTNhallway1.Enabled = false;
                BTNberthing.Enabled = true;

                //sets the location of a group box
                GBcenconroom.Location = new Point(42, 23);
                //sets the location of a group box
                GBpernav.Location = new Point(42, 340);
                //next two lines set the text box information to the array assigned
                textBox1.Text = room;
                textBox2.Text = desc;
                //sets the background image according to the array assigned
                BackgroundImage = Image.FromFile(Cosmos.getBackImage(8));

            }
            //logs location to log file
            logLocation("Corridor to Berthing");

        }

        private void corridorToMedical()
        {
            //Call the class and call it Cosmos with arrays sent into it
            area Cosmos = new area(RN, Desc, BI);
            //These two lines will call the functions with the assigned array data to change the room name and description in our groupboxes
            string room = Cosmos.getRoom(8);
            string desc = Cosmos.getDesc(8);


            //Message box will display location name 
            MessageBox.Show($"Going through: {Cosmos.getRoom(8)}");

            //Sets the current location
            currentLoc = 8;

            //if created to show and hide necessary data
            if (currentLoc == 8)
            {
                //These lines are disabling and enabling certain buttons
                BTNcencon.Enabled = true;
                BTNeng.Enabled = false;
                BTNcoms.Enabled = false;
                BTNops.Enabled = false;
                BTNsec.Enabled = false;
                BTNhallway2.Enabled = false;
                BTNhallway1.Enabled = false;
                BTNberthing.Enabled = false;
                BTNmedbay.Enabled = true;

                //sets the location of a group box
                GBcenconroom.Location = new Point(42, 23);
                //sets the location of a group box
                GBpernav.Location = new Point(42, 340);
                //next two lines set the text box information to the array assigned
                textBox1.Text = room;
                textBox2.Text = desc;
                //sets the background image according to the array assigned
                BackgroundImage = Image.FromFile(Cosmos.getBackImage(9));
            }
            //logs location to log file
            logLocation("Corridor to Medical Bay");
        }
        //Function for main menu
        private void mainMenu() 
        {
            //These lines will hide everything not meant to be on the main menu
            GBpernav.Hide();
            GBcenconroom.Hide();
            GBcompscreen.Hide();
            BTNcomputer.Hide();
            BTNback2.Hide();
            BTNaudio1.Hide();
            BTNaudio2.Hide();
            
            //Went this route for the main menu background image because it was much more simple than adding more arrays
            BackgroundImage = Image.FromFile("mainbase.jpg");
            //string variable to hold users name, enviornment collects the users desktop name
            string username = Environment.UserName;
            //This will display the welcome message with the users name
            TBwelcome.Text = "Welcome to the Cosmos Command " + username;
            //next three lines will show the welcome message, groupbox for the main menu and the "secret" button
            TBwelcome.Show();
            GBready.Show();
            BTNChilling.Show();
        }

        //Funcion for computer screen
        private void compScreen()
        {

            //Call the class and call it Cosmos with arrays sent into it so we can use the background image
            area Cosmos = new area(RN, Desc, BI);
            //sets the background image according to the array assigned
            BackgroundImage = Image.FromFile(Cosmos.getBackImage(7));
            //these lines will hide and show what is needed for this portion
            GBcenconroom.Hide();
            GBpernav.Hide();
            BTNcomputer.Hide();
            GBcompscreen.Show();
            BTNback2.Hide();
        }
        //Function for chilling moon
        private void chillingMoon()
        {
            //Call the class and call it Cosmos with arrays sent into it
            area Cosmos = new area(RN, Desc, BI);

            //sets the background image according to the array assigned
            BackgroundImage = Image.FromFile(Cosmos.getBackImage(10));
            //These lines will hide and show what is needed for this portion
            BTNback2.Show();
            TBwelcome.Hide();
            GBready.Hide();
            BTNaudio1.Show();
            BTNaudio2.Show();
            BTNChilling.Hide();
            //Disabled button until other button is pressed
            BTNaudio2.Enabled = false;
        }

        //And finally the buttons that activate each function
        //Function called when button is pressed.
        private void BTNops_Click(object sender, EventArgs e)
        {
            //Calling function for the area
            operationsRoom();
            
        }
        //Function called when button is pressed.
        private void BTNeng_Click(object sender, EventArgs e)
        {
            //Calling function for the area
            engineeringRoom();
            
        }
        //Function called when button is pressed.
        private void BTNres_Click(object sender, EventArgs e)
        {
            //Calling function for the area
            securityRoom();
        }
        //Function called when button is pressed.
        private void BTNcoms_Click(object sender, EventArgs e)
        {  
            //call function for this area
            communicationsRoom();
        }
        //Function called when button is clicked
        private void BTNcencon_Click(object sender, EventArgs e)
        {
            //Call function for the area
            centralControlRoom();
        }
        //Function called when button is clicked
        private void BTNberthing_Click(object sender, EventArgs e)
        {
            //call the berthing function
            berthing();
        }
        //Function called when button is clicked
        private void BTNmedbay_Click(object sender, EventArgs e)
        {
            //call the medical bay function
            medicalBay();
        }
        //function called when button is clicked
        private void BTNyes_Click(object sender, EventArgs e)
        {
            //Calling function to go to first area
            centralControlRoom();
            //Set these to hide so they would not be present after the main menu
            TBwelcome.Hide();
            GBready.Hide();
            BTNChilling.Hide();
            
            
        }
        //function called when button is clicked
        private void BTNChilling_Click(object sender, EventArgs e)
        {
            //call the chilling moon function
            chillingMoon();
        }
        //function called when button is clicked
        private void BTNhallway1_Click(object sender, EventArgs e)
        {
            //calls the corridor function
            corridorToMedical();
        }
        //function called when button is clicked
        private void BTNhallway2_Click(object sender, EventArgs e)
        {
            //calls the corridor berthing function
            corridorToBerthing();
        }
        //function called when button is clicked
        private void BTNno_Click(object sender, EventArgs e)
        {
            //displays when the user chooses No
            MessageBox.Show("Comeback next time!");
            //exits the application
            Application.Exit();
        }

        //function called when button is clicked
        private void BTNcomputer_Click(object sender, EventArgs e)
        {
            //calls the computer screen scene
            compScreen();
        }
        //function called when button is clicked
        private void BTNclear_Click(object sender, EventArgs e)
        {
            //clears the text box
            textBox3.Clear();
        }
        //function called when button is clicked
        private void BTNlog_Click(object sender, EventArgs e)
        {
            //assign the variable to the text box so the text there is written in the file
            string userMessage = textBox3.Text;
            //calls the log message function with the variable for the text box
            logMessage(userMessage);
            //clears the text box
            textBox3.Clear();
            //displays when the message logs
            MessageBox.Show("Message logged.");
        }
        //function called when button is clicked
        private void BTNback_Click(object sender, EventArgs e)
        {
            //Calling function for the area
            securityRoom();
        }
        //function called when button is clicked
        private void BTNread_Click(object sender, EventArgs e)
        {
            //calls the read message function
            readMessage();
            //clears the text box
            textBox3.Clear();

        }
        //function called when button is clicked
        private void BTNback2_Click(object sender, EventArgs e)
        {
            //calls the main menu function
            mainMenu();
        }
        //function called when button is clicked
        private void BTNaudio1_Click(object sender, EventArgs e)
        {
            //assigned a variable with the sound file
            soundPlayer = new SoundPlayer("invadeUs.wav");
            //if created for when the button is enabled
            if (BTNaudio1.Enabled)
            {
                //the sound assigned will play
                soundPlayer.Play();
                //second button will be enabled
                BTNaudio2.Enabled = true;
            }
        }
        //function called when button is clicked
        private void BTNaudio2_Click(object sender, EventArgs e)
        {
            //assigned a variable with the sound file
            soundPlayer = new SoundPlayer("movieStop.wav");
            //if created when the button is enabled
            if (BTNaudio2.Enabled)
            {
                //the sound assigned will play
                soundPlayer.Play();

            }
        }
    }

}
