﻿namespace Moonbase
{
    partial class Moonbase
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Moonbase));
            this.GBcenconroom = new System.Windows.Forms.GroupBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.BTNsec = new System.Windows.Forms.Button();
            this.BTNeng = new System.Windows.Forms.Button();
            this.BTNcoms = new System.Windows.Forms.Button();
            this.BTNops = new System.Windows.Forms.Button();
            this.GBpernav = new System.Windows.Forms.GroupBox();
            this.BTNmedbay = new System.Windows.Forms.Button();
            this.BTNberthing = new System.Windows.Forms.Button();
            this.BTNhallway2 = new System.Windows.Forms.Button();
            this.BTNhallway1 = new System.Windows.Forms.Button();
            this.BTNcencon = new System.Windows.Forms.Button();
            this.TBwelcome = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.BTNyes = new System.Windows.Forms.Button();
            this.BTNno = new System.Windows.Forms.Button();
            this.GBready = new System.Windows.Forms.GroupBox();
            this.BTNChilling = new System.Windows.Forms.Button();
            this.BTNcomputer = new System.Windows.Forms.Button();
            this.GBcompscreen = new System.Windows.Forms.GroupBox();
            this.BTNread = new System.Windows.Forms.Button();
            this.BTNback = new System.Windows.Forms.Button();
            this.BTNlog = new System.Windows.Forms.Button();
            this.BTNclear = new System.Windows.Forms.Button();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.BTNback2 = new System.Windows.Forms.Button();
            this.BTNaudio1 = new System.Windows.Forms.Button();
            this.BTNaudio2 = new System.Windows.Forms.Button();
            this.GBcenconroom.SuspendLayout();
            this.GBpernav.SuspendLayout();
            this.GBready.SuspendLayout();
            this.GBcompscreen.SuspendLayout();
            this.SuspendLayout();
            // 
            // GBcenconroom
            // 
            this.GBcenconroom.BackColor = System.Drawing.Color.Gainsboro;
            this.GBcenconroom.Controls.Add(this.textBox2);
            this.GBcenconroom.Controls.Add(this.label2);
            this.GBcenconroom.Controls.Add(this.textBox1);
            this.GBcenconroom.Controls.Add(this.label1);
            this.GBcenconroom.Location = new System.Drawing.Point(42, 23);
            this.GBcenconroom.Name = "GBcenconroom";
            this.GBcenconroom.Size = new System.Drawing.Size(483, 471);
            this.GBcenconroom.TabIndex = 0;
            this.GBcenconroom.TabStop = false;
            this.GBcenconroom.Text = "Location Information";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(42, 148);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(404, 270);
            this.textBox2.TabIndex = 3;
            this.textBox2.Text = resources.GetString("textBox2.Text");
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(38, 118);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(186, 26);
            this.label2.TabIndex = 2;
            this.label2.Text = "Room Description";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(42, 63);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(270, 35);
            this.textBox1.TabIndex = 1;
            this.textBox1.Text = "Central Control Room";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(38, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(136, 26);
            this.label1.TabIndex = 0;
            this.label1.Text = "Room Name";
            // 
            // BTNsec
            // 
            this.BTNsec.Location = new System.Drawing.Point(384, 173);
            this.BTNsec.Name = "BTNsec";
            this.BTNsec.Size = new System.Drawing.Size(141, 95);
            this.BTNsec.TabIndex = 3;
            this.BTNsec.Text = "Security";
            this.BTNsec.UseVisualStyleBackColor = true;
            this.BTNsec.Click += new System.EventHandler(this.BTNres_Click);
            // 
            // BTNeng
            // 
            this.BTNeng.Location = new System.Drawing.Point(212, 39);
            this.BTNeng.Name = "BTNeng";
            this.BTNeng.Size = new System.Drawing.Size(141, 95);
            this.BTNeng.TabIndex = 2;
            this.BTNeng.Text = "Engineering";
            this.BTNeng.UseVisualStyleBackColor = true;
            this.BTNeng.Click += new System.EventHandler(this.BTNeng_Click);
            // 
            // BTNcoms
            // 
            this.BTNcoms.Location = new System.Drawing.Point(212, 303);
            this.BTNcoms.Name = "BTNcoms";
            this.BTNcoms.Size = new System.Drawing.Size(141, 95);
            this.BTNcoms.TabIndex = 4;
            this.BTNcoms.Text = "Communications";
            this.BTNcoms.UseVisualStyleBackColor = true;
            this.BTNcoms.Click += new System.EventHandler(this.BTNcoms_Click);
            // 
            // BTNops
            // 
            this.BTNops.Location = new System.Drawing.Point(42, 173);
            this.BTNops.Name = "BTNops";
            this.BTNops.Size = new System.Drawing.Size(141, 95);
            this.BTNops.TabIndex = 1;
            this.BTNops.Text = "Operations";
            this.BTNops.UseVisualStyleBackColor = true;
            this.BTNops.Click += new System.EventHandler(this.BTNops_Click);
            // 
            // GBpernav
            // 
            this.GBpernav.BackColor = System.Drawing.SystemColors.Window;
            this.GBpernav.Controls.Add(this.BTNmedbay);
            this.GBpernav.Controls.Add(this.BTNberthing);
            this.GBpernav.Controls.Add(this.BTNhallway2);
            this.GBpernav.Controls.Add(this.BTNhallway1);
            this.GBpernav.Controls.Add(this.BTNcencon);
            this.GBpernav.Controls.Add(this.BTNops);
            this.GBpernav.Controls.Add(this.BTNcoms);
            this.GBpernav.Controls.Add(this.BTNeng);
            this.GBpernav.Controls.Add(this.BTNsec);
            this.GBpernav.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GBpernav.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.GBpernav.Location = new System.Drawing.Point(1278, 25);
            this.GBpernav.Name = "GBpernav";
            this.GBpernav.Size = new System.Drawing.Size(556, 455);
            this.GBpernav.TabIndex = 5;
            this.GBpernav.TabStop = false;
            this.GBpernav.Text = "Personal Nav Device";
            // 
            // BTNmedbay
            // 
            this.BTNmedbay.Location = new System.Drawing.Point(42, 316);
            this.BTNmedbay.Name = "BTNmedbay";
            this.BTNmedbay.Size = new System.Drawing.Size(106, 69);
            this.BTNmedbay.TabIndex = 8;
            this.BTNmedbay.Text = "Medical";
            this.BTNmedbay.UseVisualStyleBackColor = true;
            this.BTNmedbay.Click += new System.EventHandler(this.BTNmedbay_Click);
            // 
            // BTNberthing
            // 
            this.BTNberthing.Location = new System.Drawing.Point(419, 316);
            this.BTNberthing.Name = "BTNberthing";
            this.BTNberthing.Size = new System.Drawing.Size(106, 69);
            this.BTNberthing.TabIndex = 7;
            this.BTNberthing.Text = "Berthing";
            this.BTNberthing.UseVisualStyleBackColor = true;
            this.BTNberthing.Click += new System.EventHandler(this.BTNberthing_Click);
            // 
            // BTNhallway2
            // 
            this.BTNhallway2.Location = new System.Drawing.Point(359, 286);
            this.BTNhallway2.Name = "BTNhallway2";
            this.BTNhallway2.Size = new System.Drawing.Size(50, 29);
            this.BTNhallway2.TabIndex = 6;
            this.BTNhallway2.Text = "Hall";
            this.BTNhallway2.UseVisualStyleBackColor = true;
            this.BTNhallway2.Click += new System.EventHandler(this.BTNhallway2_Click);
            // 
            // BTNhallway1
            // 
            this.BTNhallway1.Location = new System.Drawing.Point(156, 286);
            this.BTNhallway1.Name = "BTNhallway1";
            this.BTNhallway1.Size = new System.Drawing.Size(50, 29);
            this.BTNhallway1.TabIndex = 5;
            this.BTNhallway1.Text = "Hall";
            this.BTNhallway1.UseVisualStyleBackColor = true;
            this.BTNhallway1.Click += new System.EventHandler(this.BTNhallway1_Click);
            // 
            // BTNcencon
            // 
            this.BTNcencon.Enabled = false;
            this.BTNcencon.Location = new System.Drawing.Point(212, 161);
            this.BTNcencon.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BTNcencon.Name = "BTNcencon";
            this.BTNcencon.Size = new System.Drawing.Size(135, 118);
            this.BTNcencon.TabIndex = 0;
            this.BTNcencon.Text = "Central Control";
            this.BTNcencon.UseVisualStyleBackColor = true;
            this.BTNcencon.Click += new System.EventHandler(this.BTNcencon_Click);
            // 
            // TBwelcome
            // 
            this.TBwelcome.BackColor = System.Drawing.SystemColors.HotTrack;
            this.TBwelcome.Font = new System.Drawing.Font("Microsoft Sans Serif", 26F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TBwelcome.ForeColor = System.Drawing.SystemColors.Window;
            this.TBwelcome.Location = new System.Drawing.Point(360, 50);
            this.TBwelcome.Name = "TBwelcome";
            this.TBwelcome.ReadOnly = true;
            this.TBwelcome.Size = new System.Drawing.Size(1132, 66);
            this.TBwelcome.TabIndex = 7;
            this.TBwelcome.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label3.Location = new System.Drawing.Point(51, 22);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(405, 52);
            this.label3.TabIndex = 8;
            this.label3.Text = "Ready to explore? ";
            // 
            // BTNyes
            // 
            this.BTNyes.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTNyes.Location = new System.Drawing.Point(84, 118);
            this.BTNyes.Name = "BTNyes";
            this.BTNyes.Size = new System.Drawing.Size(102, 64);
            this.BTNyes.TabIndex = 9;
            this.BTNyes.Text = "Yes";
            this.BTNyes.UseVisualStyleBackColor = true;
            this.BTNyes.Click += new System.EventHandler(this.BTNyes_Click);
            // 
            // BTNno
            // 
            this.BTNno.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTNno.Location = new System.Drawing.Point(327, 118);
            this.BTNno.Name = "BTNno";
            this.BTNno.Size = new System.Drawing.Size(102, 64);
            this.BTNno.TabIndex = 10;
            this.BTNno.Text = "No";
            this.BTNno.UseVisualStyleBackColor = true;
            this.BTNno.Click += new System.EventHandler(this.BTNno_Click);
            // 
            // GBready
            // 
            this.GBready.BackColor = System.Drawing.Color.Transparent;
            this.GBready.Controls.Add(this.label3);
            this.GBready.Controls.Add(this.BTNyes);
            this.GBready.Controls.Add(this.BTNno);
            this.GBready.Location = new System.Drawing.Point(656, 171);
            this.GBready.Name = "GBready";
            this.GBready.Size = new System.Drawing.Size(528, 208);
            this.GBready.TabIndex = 11;
            this.GBready.TabStop = false;
            // 
            // BTNChilling
            // 
            this.BTNChilling.Location = new System.Drawing.Point(1827, 935);
            this.BTNChilling.Name = "BTNChilling";
            this.BTNChilling.Size = new System.Drawing.Size(28, 28);
            this.BTNChilling.TabIndex = 12;
            this.BTNChilling.UseVisualStyleBackColor = true;
            this.BTNChilling.Click += new System.EventHandler(this.BTNChilling_Click);
            // 
            // BTNcomputer
            // 
            this.BTNcomputer.Location = new System.Drawing.Point(1619, 622);
            this.BTNcomputer.Name = "BTNcomputer";
            this.BTNcomputer.Size = new System.Drawing.Size(118, 62);
            this.BTNcomputer.TabIndex = 13;
            this.BTNcomputer.Text = "Computer";
            this.BTNcomputer.UseVisualStyleBackColor = true;
            this.BTNcomputer.Click += new System.EventHandler(this.BTNcomputer_Click);
            // 
            // GBcompscreen
            // 
            this.GBcompscreen.BackColor = System.Drawing.Color.Transparent;
            this.GBcompscreen.Controls.Add(this.BTNread);
            this.GBcompscreen.Controls.Add(this.BTNback);
            this.GBcompscreen.Controls.Add(this.BTNlog);
            this.GBcompscreen.Controls.Add(this.BTNclear);
            this.GBcompscreen.Controls.Add(this.textBox3);
            this.GBcompscreen.Location = new System.Drawing.Point(1018, 385);
            this.GBcompscreen.Name = "GBcompscreen";
            this.GBcompscreen.Size = new System.Drawing.Size(346, 344);
            this.GBcompscreen.TabIndex = 14;
            this.GBcompscreen.TabStop = false;
            this.GBcompscreen.Text = "Security Log";
            // 
            // BTNread
            // 
            this.BTNread.Location = new System.Drawing.Point(228, 237);
            this.BTNread.Name = "BTNread";
            this.BTNread.Size = new System.Drawing.Size(91, 35);
            this.BTNread.TabIndex = 16;
            this.BTNread.Text = "Read Log";
            this.BTNread.UseVisualStyleBackColor = true;
            this.BTNread.Click += new System.EventHandler(this.BTNread_Click);
            // 
            // BTNback
            // 
            this.BTNback.Location = new System.Drawing.Point(208, 287);
            this.BTNback.Name = "BTNback";
            this.BTNback.Size = new System.Drawing.Size(75, 38);
            this.BTNback.TabIndex = 15;
            this.BTNback.Text = "Back";
            this.BTNback.UseVisualStyleBackColor = true;
            this.BTNback.Click += new System.EventHandler(this.BTNback_Click);
            // 
            // BTNlog
            // 
            this.BTNlog.Location = new System.Drawing.Point(25, 237);
            this.BTNlog.Name = "BTNlog";
            this.BTNlog.Size = new System.Drawing.Size(75, 35);
            this.BTNlog.TabIndex = 2;
            this.BTNlog.Text = "Log";
            this.BTNlog.UseVisualStyleBackColor = true;
            this.BTNlog.Click += new System.EventHandler(this.BTNlog_Click);
            // 
            // BTNclear
            // 
            this.BTNclear.Location = new System.Drawing.Point(76, 290);
            this.BTNclear.Name = "BTNclear";
            this.BTNclear.Size = new System.Drawing.Size(75, 35);
            this.BTNclear.TabIndex = 1;
            this.BTNclear.Text = "Clear";
            this.BTNclear.UseVisualStyleBackColor = true;
            this.BTNclear.Click += new System.EventHandler(this.BTNclear_Click);
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(25, 39);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(292, 184);
            this.textBox3.TabIndex = 0;
            // 
            // BTNback2
            // 
            this.BTNback2.Location = new System.Drawing.Point(1743, 857);
            this.BTNback2.Name = "BTNback2";
            this.BTNback2.Size = new System.Drawing.Size(127, 34);
            this.BTNback2.TabIndex = 15;
            this.BTNback2.Text = "Back to Main";
            this.BTNback2.UseVisualStyleBackColor = true;
            this.BTNback2.Click += new System.EventHandler(this.BTNback2_Click);
            // 
            // BTNaudio1
            // 
            this.BTNaudio1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.BTNaudio1.Location = new System.Drawing.Point(963, 452);
            this.BTNaudio1.Name = "BTNaudio1";
            this.BTNaudio1.Size = new System.Drawing.Size(28, 28);
            this.BTNaudio1.TabIndex = 16;
            this.BTNaudio1.UseVisualStyleBackColor = false;
            this.BTNaudio1.Click += new System.EventHandler(this.BTNaudio1_Click);
            // 
            // BTNaudio2
            // 
            this.BTNaudio2.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.BTNaudio2.Location = new System.Drawing.Point(582, 531);
            this.BTNaudio2.Name = "BTNaudio2";
            this.BTNaudio2.Size = new System.Drawing.Size(28, 28);
            this.BTNaudio2.TabIndex = 17;
            this.BTNaudio2.UseVisualStyleBackColor = false;
            this.BTNaudio2.Click += new System.EventHandler(this.BTNaudio2_Click);
            // 
            // Moonbase
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1898, 1024);
            this.Controls.Add(this.BTNaudio2);
            this.Controls.Add(this.BTNaudio1);
            this.Controls.Add(this.BTNback2);
            this.Controls.Add(this.GBcompscreen);
            this.Controls.Add(this.BTNcomputer);
            this.Controls.Add(this.BTNChilling);
            this.Controls.Add(this.GBready);
            this.Controls.Add(this.TBwelcome);
            this.Controls.Add(this.GBpernav);
            this.Controls.Add(this.GBcenconroom);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Moonbase";
            this.Text = "Cosmos Command";
            this.GBcenconroom.ResumeLayout(false);
            this.GBcenconroom.PerformLayout();
            this.GBpernav.ResumeLayout(false);
            this.GBready.ResumeLayout(false);
            this.GBready.PerformLayout();
            this.GBcompscreen.ResumeLayout(false);
            this.GBcompscreen.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox GBcenconroom;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button BTNsec;
        private System.Windows.Forms.Button BTNeng;
        private System.Windows.Forms.Button BTNcoms;
        private System.Windows.Forms.Button BTNops;
        private System.Windows.Forms.GroupBox GBpernav;
        private System.Windows.Forms.Button BTNcencon;
        private System.Windows.Forms.TextBox TBwelcome;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button BTNyes;
        private System.Windows.Forms.Button BTNno;
        private System.Windows.Forms.GroupBox GBready;
        private System.Windows.Forms.Button BTNChilling;
        private System.Windows.Forms.Button BTNhallway2;
        private System.Windows.Forms.Button BTNhallway1;
        private System.Windows.Forms.Button BTNberthing;
        private System.Windows.Forms.Button BTNmedbay;
        private System.Windows.Forms.Button BTNcomputer;
        private System.Windows.Forms.GroupBox GBcompscreen;
        private System.Windows.Forms.Button BTNlog;
        private System.Windows.Forms.Button BTNclear;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Button BTNback;
        private System.Windows.Forms.Button BTNread;
        private System.Windows.Forms.Button BTNback2;
        private System.Windows.Forms.Button BTNaudio1;
        private System.Windows.Forms.Button BTNaudio2;
    }
}

